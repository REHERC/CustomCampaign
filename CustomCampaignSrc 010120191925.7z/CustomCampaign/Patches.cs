﻿using Harmony;

namespace CustomCampaign
{
    [HarmonyPatch(typeof(LevelGridMenu))]
    [HarmonyPatch("CreateEntries")]
    public class LevelGridMenu__CreateEntries__Patch
    {
        static void Postfix(LevelGridMenu __instance)
        {
            //TODO: add code to add the level playlist button thing to the campaign menu
            bool flag_campaignmode = __instance.GetPrivateField<bool>("isCampaignMode_");
        }
    }
}
